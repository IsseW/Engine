#include"assets.h"

Mesh unit_cube();